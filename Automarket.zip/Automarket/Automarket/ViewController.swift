//
//  ViewController.swift
//  Automarket
//
//  Created by 17815062 on 10.10.2020.
//  Copyright © 2020 17815062. All rights reserved.
//

import UIKit

class StartViewController: UIViewController {

	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view.
	}
}

